MANACART2HOME COMPLETE WEBSITE

Files included: index.html, style.css, script.js, and images/rice folder placeholder.

HOW TO USE
1. Extract this ZIP.
2. Copy your 14 rice JPG images into images/rice/ using the exact filenames listed in the placeholder text file.
3. Open index.html with VS Code Live Server.

All product data and rates were retained from the supplied working script.js. Verify all rates and pack sizes before publishing.

The checkout button prepares and copies an order summary when clipboard access is available. It does not send an order automatically; a verified store WhatsApp number/payment flow must be configured separately.
